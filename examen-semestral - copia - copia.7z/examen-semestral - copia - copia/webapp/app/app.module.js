(function() {
    'use strict';

    angular
        .module('mitchapp', [
            'ui.router',
            'ngMaterial',
            'ngStorage',
            'ui.bootstrap',
            'aa.formExtensions'
        ]);

})();
